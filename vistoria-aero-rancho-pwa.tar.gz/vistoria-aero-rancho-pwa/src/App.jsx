import { useState, useMemo, useCallback } from "react";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend
} from "recharts";

const TECHNICIANS = [
  "EVANDRO MIGUEL","LUAN FELIPE","GABRIEL","WAGNER BAREN",
  "JOELMIR","MANOEL MENDES","WALBER COSTA","APARECIDO DIAS",
  "EZEQUIEL CUENGA","GERTHNEY","DIEGO RIOS","LANDER OJEDA"
];
const SUPERVISORS = ["Dionizio Pretes","Weslley Fortunato","Outro Supervisor"];
const TIPOS = { start:"Start / Organização", on:"ON – Atendimento", off:"OFF – Execução Externa", imp:"Imprevista – Segurança" };
const TIPO_COLORS = { start:"#f59e0b", on:"#10b981", off:"#3b82f6", imp:"#ef4444" };
const TIPO_ICONS = { start:"🚀", on:"✅", off:"🔧", imp:"⚠️" };

const QUESTIONS = {
  start: [
    { id:"s1", text:"O técnico e auxiliar estão chegando no horário para retirada de material?" },
    { id:"s2", text:"O veículo da equipe está organizado internamente sem resíduos de sujeira?" },
    { id:"s3", text:"A apresentação da equipe está de acordo para o dia?" },
  ],
  off: [
    { id:"o1", text:"O lançamento do cabo drop está adequado?" },
    { id:"o2", text:"Fez uso de plaqueta de identificação?" },
    { id:"o3", text:"O cabo está na altura correta?" },
    { id:"o4", text:"O cabo seguiu corretamente a rede de energia?" },
    { id:"o5", text:"A ancoragem foi realizada na equipagem da empresa?" },
    { id:"o6", text:"A CTO está organizada e vedada?" },
    { id:"o7", text:"Há vestígios de cabos soltos que poderiam ser retirados?" },
  ],
  on: [
    { id:"n1", text:"A equipe está bem sincronizada com o procedimento do manual no trabalho em dupla?" },
    { id:"n2", text:"O técnico se identificou ao cliente e perguntou o nome do assinante?" },
    { id:"n3", text:"O técnico demonstrou o catálogo de padrão e entrou em acordo ao realizar o serviço?" },
    { id:"n4", text:"O tempo de tomada de decisão para iniciar o serviço está adequado?" },
    { id:"n5", text:"A equipe fez a análise de risco antes de iniciar os serviços?" },
    { id:"n6", text:"O tempo de execução do lançamento da CTO até a residência está no prazo esperado?" },
  ],
  imp: [
    { id:"i1", text:"O veículo da empresa está estacionado corretamente e sinalizado?" },
    { id:"i2", text:"A equipe estava utilizando a linha de vida com trava-queda?" },
    { id:"i3", text:"A equipe está utilizando todos os EPIs?" },
    { id:"i4", text:"A condução do trabalho está segura?" },
  ],
};

const ALL_Q_MAP = {};
Object.values(QUESTIONS).forEach(arr => arr.forEach(q => { ALL_Q_MAP[q.id] = q.text; }));

function scoreVal(v) { return v==="sim"?10:v==="parcial"?5:0; }

function calcScore(v) {
  const qs = QUESTIONS[v.tipo]||[];
  if(!qs.length) return 0;
  let total=0;
  qs.forEach(q=>{ total+=scoreVal(v.respostas?.[q.id]); });
  if(v.tipo==="on"&&v.nota) total+=v.nota*2;
  const max=qs.length*10+(v.tipo==="on"?10:0);
  return Math.round((total/max)*100);
}

function buildMock() {
  const now=new Date(); const data=[];
  for(let i=0;i<55;i++){
    const d=new Date(now); d.setDate(d.getDate()-Math.floor(Math.random()*90));
    const tipo=["start","on","off","imp"][Math.floor(Math.random()*4)];
    const qs=QUESTIONS[tipo]; const respostas={};
    qs.forEach(q=>{ const r=Math.random(); respostas[q.id]=r>0.62?"sim":r>0.28?"parcial":"nao"; });
    const tech=TECHNICIANS[Math.floor(Math.random()*TECHNICIANS.length)];
    const sup=SUPERVISORS[Math.floor(Math.random()*SUPERVISORS.length)];
    const nota=tipo==="on"?Math.ceil(Math.random()*5):null;
    const v={id:i+1,date:d.toISOString().split("T")[0],supervisor:sup,technician:tech,os:`OS-${20000+i}`,tipo,respostas,nota,obs:"",fotos:[]};
    v.score=calcScore(v); data.push(v);
  }
  return data.sort((a,b)=>new Date(b.date)-new Date(a.date));
}

const cn=(...c)=>c.filter(Boolean).join(" ");

function TipoBadge({tipo}){
  const c=TIPO_COLORS[tipo];
  const l={start:"Start",on:"ON",off:"OFF",imp:"Imprevista"}[tipo];
  return <span style={{background:c+"22",color:c,border:`1px solid ${c}44`}} className="text-xs font-bold px-2.5 py-1 rounded-full inline-flex items-center gap-1">{TIPO_ICONS[tipo]} {l}</span>;
}

function ScoreBadge({score,size="md"}){
  const c=score>=80?"#10b981":score>=55?"#f59e0b":"#ef4444";
  const l=score>=80?"Bom":score>=55?"Atenção":"Crítico";
  const s={sm:"text-xs px-2 py-0.5",md:"text-sm px-3 py-1",lg:"text-base px-4 py-1.5"}[size];
  return <span style={{background:c+"22",color:c,border:`1px solid ${c}44`}} className={cn("font-black rounded-full",s)}>{score}% · {l}</span>;
}

function Card({children,className=""}){
  return <div className={cn("rounded-2xl border border-white/8 bg-white/4 p-5",className)}>{children}</div>;
}

function SectionTitle({icon,children}){
  return <h3 className="text-white font-black text-sm flex items-center gap-2 mb-4 uppercase tracking-wide">{icon} {children}</h3>;
}

function TriBtn({value,onChange,boolOnly}){
  const opts=boolOnly?[{v:"sim",l:"Sim"},{v:"nao",l:"Não"}]:[{v:"sim",l:"Sim"},{v:"parcial",l:"Parcial"},{v:"nao",l:"Não"}];
  return (
    <div className="flex gap-2 mt-3">
      {opts.map(({v,l})=>(
        <button key={v} onClick={()=>onChange(v)}
          className={cn("flex-1 py-4 rounded-xl font-bold text-sm transition-all border-2",
            value===v
              ?v==="sim"?"bg-emerald-500 border-emerald-400 text-white shadow-lg shadow-emerald-500/20"
              :v==="parcial"?"bg-amber-400 border-amber-300 text-white shadow-lg shadow-amber-400/20"
              :"bg-red-500 border-red-400 text-white shadow-lg shadow-red-500/20"
              :"bg-white/5 border-white/10 text-white/50 hover:border-white/30 hover:text-white"
          )}>
          {v==="sim"?"✓ ":v==="nao"?"✗ ":"◐ "}{l}
        </button>
      ))}
    </div>
  );
}

// ── HOME ─────────────────────────────────────────────────────────────────────────
function Home({setS,total,avg}){
  const btns=[
    {id:"nova",icon:"📋",label:"Nova Vistoria",desc:"Registrar fiscalização de campo",color:"#3b82f6"},
    {id:"historico",icon:"🗂️",label:"Histórico",desc:"Consultar vistorias anteriores",color:"#8b5cf6"},
    {id:"dashboard",icon:"📊",label:"Dashboard",desc:"Indicadores e métricas gerais",color:"#10b981"},
    {id:"ranking",icon:"🏆",label:"Ranking Técnicos",desc:"Desempenho individual",color:"#f59e0b"},
    {id:"atencao",icon:"⚠️",label:"Pontos de Atenção",desc:"Falhas e alertas operacionais",color:"#ef4444"},
  ];
  return (
    <div className="flex flex-col min-h-screen">
      <div className="px-5 pt-8 pb-5">
        <div className="flex items-center gap-3 mb-6">
          <div style={{background:"linear-gradient(135deg,#3b82f6,#1e40af)"}} className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-xl shadow-blue-500/30">📡</div>
          <div>
            <div className="text-white font-black text-xl leading-tight">Aero Rancho</div>
            <div className="text-white/35 text-xs font-medium">Sistema de Fiscalização Operacional</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 mb-1">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4 text-center">
            <div className="text-4xl font-black text-blue-400 leading-none">{total}</div>
            <div className="text-white/35 text-xs mt-1">vistorias</div>
          </div>
          <div className={cn("border rounded-2xl p-4 text-center",avg>=80?"bg-emerald-500/10 border-emerald-500/20":avg>=55?"bg-amber-500/10 border-amber-500/20":"bg-red-500/10 border-red-500/20")}>
            <div className={cn("text-4xl font-black leading-none",avg>=80?"text-emerald-400":avg>=55?"text-amber-400":"text-red-400")}>{avg}%</div>
            <div className="text-white/35 text-xs mt-1">conformidade</div>
          </div>
        </div>
      </div>
      <div className="px-5 space-y-3 flex-1 pb-6">
        {btns.map((b,i)=>(
          <button key={b.id} onClick={()=>setS(b.id)}
            className="w-full flex items-center gap-4 bg-white/4 border border-white/8 rounded-2xl p-4 hover:bg-white/8 hover:border-white/18 transition-all text-left group">
            <div style={{background:b.color+"1a",border:`1.5px solid ${b.color}44`}} className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0 group-hover:scale-110 transition-transform">{b.icon}</div>
            <div className="flex-1 min-w-0">
              <div className="text-white font-bold text-sm">{b.label}</div>
              <div className="text-white/35 text-xs mt-0.5">{b.desc}</div>
            </div>
            <div className="text-white/20 text-xl font-light">›</div>
          </button>
        ))}
      </div>
      <div className="text-center py-4 text-white/12 text-xs">PA Aero Rancho · Supervisão Dionizio Pretes</div>
    </div>
  );
}

// ── NOVA VISTORIA ─────────────────────────────────────────────────────────────────
function NovaVistoria({onSave,setS}){
  const [step,setStep]=useState(0);
  const [done,setDone]=useState(false);
  const [form,setForm]=useState({
    date:new Date().toISOString().split("T")[0],
    supervisor:"",technician:"",os:"",tipo:"",
    respostas:{},nota:null,obs:"",
  });
  const f=(k,v)=>setForm(p=>({...p,[k]:v}));
  const fr=(k,v)=>setForm(p=>({...p,respostas:{...p.respostas,[k]:v}}));
  const qs=form.tipo?QUESTIONS[form.tipo]:[];
  const s0ok=form.date&&form.supervisor&&form.technician&&form.os&&form.tipo;
  const s1ok=qs.every(q=>form.respostas[q.id]);
  const BOOL_IDS=["i2","i3","n2","n5"];

  const save=()=>{
    const v={...form,id:Date.now(),fotos:[]};
    v.score=calcScore(v); onSave(v); setDone(true);
    setTimeout(()=>{setDone(false);setS("home");},1800);
  };

  const tipoOpts=[
    {k:"start",icon:"🚀",label:"Start / Organização",desc:"Retirada de material e organização do dia"},
    {k:"off",icon:"🔧",label:"OFF – Execução Externa",desc:"Lançamento cabo drop e CTO"},
    {k:"on",icon:"✅",label:"ON – Atendimento e Execução",desc:"Atendimento ao cliente e execução"},
    {k:"imp",icon:"⚠️",label:"Imprevista – Segurança",desc:"Vistoria não programada de segurança"},
  ];

  if(done) return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-5">
      <div style={{animation:"pop .4s ease"}} className="text-8xl">✅</div>
      <div className="text-white font-black text-2xl">Vistoria Salva!</div>
      <div className="text-white/40">Redirecionando para início...</div>
      <style>{`@keyframes pop{0%{transform:scale(0)}80%{transform:scale(1.15)}100%{transform:scale(1)}}`}</style>
    </div>
  );

  const steps=["Dados","Perguntas","Revisão"];

  return (
    <div className="flex flex-col min-h-screen">
      <div className="sticky top-0 z-30 bg-[#080f1e]/96 backdrop-blur border-b border-white/8 px-4 py-3 flex items-center gap-3">
        <button onClick={()=>step>0?setStep(s=>s-1):setS("home")} className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center text-white/70 hover:text-white">←</button>
        <div className="flex-1">
          <div className="text-white font-bold text-sm">Nova Vistoria</div>
          <div className="text-white/35 text-xs">{steps[step]}</div>
        </div>
        <div className="flex gap-1.5">
          {steps.map((_,i)=>(
            <div key={i} className={cn("h-1.5 rounded-full transition-all duration-300",i<step?"bg-emerald-500 w-4":i===step?"bg-blue-500 w-7":"bg-white/15 w-3")} />
          ))}
        </div>
      </div>

      <div className="flex-1 px-4 py-5 space-y-4">
        {step===0&&(
          <>
            {[{k:"date",l:"Data *",type:"date"},{k:"os",l:"Ordem de Serviço *",type:"text",ph:"Ex: OS-12345"}].map(({k,l,type,ph})=>(
              <div key={k}>
                <label className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 block">{l}</label>
                <input type={type} placeholder={ph} value={form[k]} onChange={e=>f(k,e.target.value)}
                  className="w-full bg-white/6 border border-white/12 text-white rounded-xl px-4 py-3.5 text-sm outline-none focus:border-blue-500 placeholder-white/20 transition-colors"/>
              </div>
            ))}
            {[{k:"supervisor",l:"Supervisor *",opts:SUPERVISORS},{k:"technician",l:"Técnico / Equipe *",opts:TECHNICIANS}].map(({k,l,opts})=>(
              <div key={k}>
                <label className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 block">{l}</label>
                <select value={form[k]} onChange={e=>f(k,e.target.value)}
                  className="w-full bg-white/6 border border-white/12 text-white rounded-xl px-4 py-3.5 text-sm outline-none focus:border-blue-500 transition-colors">
                  <option value="">Selecionar...</option>
                  {opts.map(o=><option key={o}>{o}</option>)}
                </select>
              </div>
            ))}
            <div>
              <label className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-3 block">Tipo de Vistoria *</label>
              <div className="space-y-2">
                {tipoOpts.map(t=>(
                  <button key={t.k} onClick={()=>f("tipo",t.k)}
                    style={form.tipo===t.k?{borderColor:TIPO_COLORS[t.k],background:TIPO_COLORS[t.k]+"18"}:{}}
                    className={cn("w-full flex items-center gap-3 rounded-2xl p-4 border-2 transition-all text-left",form.tipo===t.k?"":"border-white/10 bg-white/4 hover:border-white/22")}>
                    <span className="text-2xl">{t.icon}</span>
                    <div className="flex-1"><div className="text-white font-bold text-sm">{t.label}</div><div className="text-white/35 text-xs">{t.desc}</div></div>
                    {form.tipo===t.k&&<div style={{color:TIPO_COLORS[t.k]}} className="font-black text-lg">✓</div>}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {step===1&&(
          <>
            <div style={{background:TIPO_COLORS[form.tipo]+"15",borderColor:TIPO_COLORS[form.tipo]+"40"}}
              className="border rounded-2xl p-3.5 flex items-center gap-3">
              <span className="text-2xl">{TIPO_ICONS[form.tipo]}</span>
              <div>
                <div style={{color:TIPO_COLORS[form.tipo]}} className="font-black text-sm">{TIPOS[form.tipo]}</div>
                <div className="text-white/35 text-xs">{qs.length} itens de conformidade</div>
              </div>
            </div>

            {qs.map((q,i)=>(
              <div key={q.id} className="bg-white/4 border border-white/8 rounded-2xl p-4">
                <div className="flex gap-2">
                  <span className="text-white/20 text-xs font-black mt-0.5 w-5 flex-shrink-0">{i+1}.</span>
                  <p className="text-white/85 text-sm leading-relaxed">{q.text}</p>
                </div>
                <TriBtn value={form.respostas[q.id]} onChange={v=>fr(q.id,v)} boolOnly={BOOL_IDS.includes(q.id)} />
              </div>
            ))}

            {form.tipo==="on"&&(
              <div className="bg-amber-500/8 border border-amber-500/20 rounded-2xl p-4">
                <p className="text-white/90 text-sm font-semibold">Qual nota você dá para o serviço executado?</p>
                <div className="flex gap-2 mt-3">
                  {[1,2,3,4,5].map(n=>(
                    <button key={n} onClick={()=>f("nota",n)}
                      className={cn("flex-1 py-3.5 rounded-xl font-black text-sm border-2 transition-all",
                        form.nota===n?"bg-amber-400 border-amber-300 text-black shadow-lg shadow-amber-400/25":"bg-white/5 border-white/12 text-white/50 hover:border-amber-500/40 hover:text-amber-400"
                      )}>★ {n}</button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <label className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 block">Anotações para Feedback</label>
              <textarea value={form.obs} onChange={e=>f("obs",e.target.value)} rows={4}
                placeholder="Descreva observações para feedback ao técnico..."
                className="w-full bg-white/6 border border-white/12 text-white rounded-xl px-4 py-3 text-sm outline-none focus:border-blue-500 resize-none placeholder-white/20"/>
            </div>
            <div className="border-2 border-dashed border-white/12 rounded-2xl p-6 text-center cursor-pointer hover:border-white/25 transition-colors">
              <div className="text-3xl mb-2">📷</div>
              <div className="text-white/45 text-sm font-medium">Anexar Fotos</div>
              <div className="text-white/22 text-xs mt-1">Toque para adicionar registros fotográficos</div>
            </div>
          </>
        )}

        {step===2&&(
          <>
            <div className="text-center py-5">
              <div className="text-5xl mb-3">📝</div>
              <div className="text-white font-black text-lg">Revisar e Confirmar</div>
            </div>
            {[["Técnico",form.technician],["Supervisor",form.supervisor],["OS",form.os],["Data",form.date],["Tipo",TIPOS[form.tipo]]].map(([l,v])=>(
              <div key={l} className="flex justify-between py-2.5 border-b border-white/6">
                <span className="text-white/40 text-sm">{l}</span>
                <span className="text-white font-semibold text-sm">{v}</span>
              </div>
            ))}
            <div className="bg-white/4 border border-white/8 rounded-2xl p-4 mt-2">
              <div className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-3">Respostas</div>
              {qs.map(q=>(
                <div key={q.id} className="flex justify-between items-start py-2 border-b border-white/5 last:border-0 gap-2">
                  <span className="text-white/55 text-xs leading-relaxed flex-1">{q.text.substring(0,55)}...</span>
                  <span className={cn("text-xs font-black flex-shrink-0",form.respostas[q.id]==="sim"?"text-emerald-400":form.respostas[q.id]==="parcial"?"text-amber-400":"text-red-400")}>
                    {form.respostas[q.id]==="sim"?"✓ SIM":form.respostas[q.id]==="parcial"?"◐ PARCIAL":"✗ NÃO"}
                  </span>
                </div>
              ))}
            </div>
            {(()=>{const p={...form,id:Date.now(),fotos:[]};p.score=calcScore(p);return(
              <div className="text-center py-3"><div className="text-white/35 text-xs mb-2">Score estimado</div><ScoreBadge score={p.score} size="lg"/></div>
            );})()}
          </>
        )}
      </div>

      <div className="sticky bottom-0 px-4 pb-6 pt-3 bg-gradient-to-t from-[#080f1e] via-[#080f1e]/90 to-transparent">
        {step<2?(
          <button disabled={step===0?!s0ok:!s1ok} onClick={()=>setStep(s=>s+1)}
            className={cn("w-full py-4 rounded-2xl font-black text-base transition-all",
              (step===0?s0ok:s1ok)?"bg-blue-600 text-white shadow-xl shadow-blue-500/25 hover:bg-blue-500 active:scale-98":"bg-white/8 text-white/25 cursor-not-allowed"
            )}>
            {step===0?"Avançar para Perguntas →":"Avançar para Revisão →"}
          </button>
        ):(
          <button onClick={save} className="w-full py-4 rounded-2xl font-black text-base bg-emerald-600 text-white shadow-xl shadow-emerald-500/25 hover:bg-emerald-500 active:scale-98 transition-all">
            ✅ Confirmar e Salvar Vistoria
          </button>
        )}
      </div>
    </div>
  );
}

// ── HISTÓRICO ─────────────────────────────────────────────────────────────────────
function Historico({data,setS}){
  const [detail,setDetail]=useState(null);
  const [search,setSearch]=useState("");
  const [ft,setFt]=useState("todos");

  const filtered=useMemo(()=>data.filter(v=>{
    if(ft!=="todos"&&v.tipo!==ft)return false;
    if(search&&!v.technician.toLowerCase().includes(search.toLowerCase())&&!v.os.toLowerCase().includes(search.toLowerCase()))return false;
    return true;
  }),[data,ft,search]);

  if(detail){
    const qs=QUESTIONS[detail.tipo]||[];
    return(
      <div className="flex flex-col min-h-screen">
        <div className="sticky top-0 z-30 bg-[#080f1e]/96 backdrop-blur border-b border-white/8 px-4 py-3 flex items-center gap-3">
          <button onClick={()=>setDetail(null)} className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center text-white/70">←</button>
          <div className="flex-1 min-w-0">
            <div className="text-white font-bold text-sm truncate">{detail.technician}</div>
            <div className="text-white/35 text-xs">{detail.date} · {detail.os}</div>
          </div>
          <TipoBadge tipo={detail.tipo}/>
        </div>
        <div className="flex-1 px-4 py-5 space-y-4">
          <div className="text-center py-3"><ScoreBadge score={detail.score} size="lg"/><div className="text-white/25 text-xs mt-2">Score desta vistoria</div></div>
          {[["Supervisor",detail.supervisor],["Técnico",detail.technician],["OS",detail.os],["Data",detail.date],["Tipo",TIPOS[detail.tipo]]].map(([l,v])=>(
            <div key={l} className="flex justify-between py-2.5 border-b border-white/6">
              <span className="text-white/40 text-sm">{l}</span>
              <span className="text-white font-semibold text-sm">{v}</span>
            </div>
          ))}
          <div>
            <div className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-3">Respostas da Vistoria</div>
            {qs.map(q=>(
              <div key={q.id} className="bg-white/4 border border-white/8 rounded-xl p-3.5 mb-2">
                <p className="text-white/65 text-xs leading-relaxed">{q.text}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className={cn("text-xs font-black",detail.respostas[q.id]==="sim"?"text-emerald-400":detail.respostas[q.id]==="parcial"?"text-amber-400":"text-red-400")}>
                    {detail.respostas[q.id]==="sim"?"✓ SIM":detail.respostas[q.id]==="parcial"?"◐ PARCIAL":"✗ NÃO"}
                  </span>
                  <span className="text-white/30 text-xs">{scoreVal(detail.respostas[q.id])} pts</span>
                </div>
              </div>
            ))}
          </div>
          {detail.tipo==="on"&&detail.nota&&(
            <div className="bg-amber-500/10 border border-amber-500/22 rounded-xl p-4 text-center">
              <div className="text-amber-400 font-black text-xl">{"★".repeat(detail.nota)}{"☆".repeat(5-detail.nota)}</div>
              <div className="text-amber-400/60 text-xs mt-1">Nota do serviço: {detail.nota}/5</div>
            </div>
          )}
          {detail.obs&&(
            <div className="bg-white/4 border border-white/8 rounded-xl p-4">
              <div className="text-white/35 text-xs font-semibold uppercase tracking-wider mb-2">Observações</div>
              <p className="text-white/65 text-sm leading-relaxed">{detail.obs}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return(
    <div className="flex flex-col min-h-screen">
      <div className="sticky top-0 z-30 bg-[#080f1e]/96 backdrop-blur border-b border-white/8 px-4 py-3 flex items-center gap-3">
        <button onClick={()=>setS("home")} className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center text-white/70">←</button>
        <div className="flex-1 font-bold text-white text-sm">Histórico de Vistorias</div>
        <span className="text-white/25 text-xs">{filtered.length} reg.</span>
      </div>
      <div className="px-4 pt-4 pb-2 space-y-3">
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar por técnico ou OS..."
          className="w-full bg-white/6 border border-white/12 text-white rounded-xl px-4 py-3 text-sm outline-none focus:border-blue-500 placeholder-white/22"/>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {[["todos","Todos"],["start","Start"],["on","ON"],["off","OFF"],["imp","Imprevista"]].map(([k,l])=>(
            <button key={k} onClick={()=>setFt(k)}
              className={cn("flex-shrink-0 text-xs px-3.5 py-1.5 rounded-full border font-bold transition-all",
                ft===k?"bg-blue-500 border-blue-400 text-white":"border-white/15 text-white/40 hover:border-white/30 hover:text-white"
              )}>{l}</button>
          ))}
        </div>
      </div>
      <div className="flex-1 px-4 py-2 space-y-2">
        {filtered.slice(0,40).map(v=>(
          <button key={v.id} onClick={()=>setDetail(v)}
            className="w-full flex items-center gap-3 bg-white/4 border border-white/8 rounded-2xl p-4 hover:bg-white/8 transition-all text-left">
            <div style={{background:TIPO_COLORS[v.tipo]+"1a"}} className="w-11 h-11 rounded-xl flex items-center justify-center text-xl flex-shrink-0">{TIPO_ICONS[v.tipo]}</div>
            <div className="flex-1 min-w-0">
              <div className="text-white font-bold text-sm truncate">{v.technician}</div>
              <div className="text-white/35 text-xs mt-0.5">{v.date} · {v.os}</div>
              <div className="mt-1.5"><TipoBadge tipo={v.tipo}/></div>
            </div>
            <div className="flex-shrink-0"><ScoreBadge score={v.score} size="sm"/></div>
          </button>
        ))}
        {!filtered.length&&<div className="text-center py-12 text-white/25">Nenhuma vistoria encontrada.</div>}
      </div>
    </div>
  );
}

// ── DASHBOARD ─────────────────────────────────────────────────────────────────────
function Dashboard({data,setS}){
  const [fp,setFp]=useState("90");
  const [ft,setFt]=useState("todos");
  const [fs,setFs]=useState("todos");
  const [ftech,setFtech]=useState("todos");

  const filtered=useMemo(()=>{
    const cut=new Date();cut.setDate(cut.getDate()-parseInt(fp));
    return data.filter(v=>{
      if(new Date(v.date)<cut)return false;
      if(ft!=="todos"&&v.tipo!==ft)return false;
      if(fs!=="todos"&&v.supervisor!==fs)return false;
      if(ftech!=="todos"&&v.technician!==ftech)return false;
      return true;
    });
  },[data,fp,ft,fs,ftech]);

  const stats=useMemo(()=>{
    if(!filtered.length)return null;
    let sim=0,nao=0,parcial=0,totalR=0;
    const tipoCount={};
    const monthly={};
    const supMap={};

    filtered.forEach(v=>{
      const qs=QUESTIONS[v.tipo]||[];
      tipoCount[v.tipo]=(tipoCount[v.tipo]||0)+1;
      const m=v.date.substring(0,7);
      if(!monthly[m])monthly[m]={total:0,score:0};
      monthly[m].total++;monthly[m].score+=v.score;
      if(!supMap[v.supervisor])supMap[v.supervisor]={scores:[],count:0};
      supMap[v.supervisor].scores.push(v.score);supMap[v.supervisor].count++;
      qs.forEach(q=>{
        totalR++;const r=v.respostas[q.id];
        if(r==="sim")sim++;else if(r==="parcial")parcial++;else nao++;
      });
    });

    const avgScore=Math.round(filtered.reduce((a,b)=>a+b.score,0)/filtered.length);
    const pieData=Object.entries(tipoCount).map(([tipo,count])=>({
      name:{start:"Start",on:"ON",off:"OFF",imp:"Imprevista"}[tipo],value:count,color:TIPO_COLORS[tipo]
    }));
    const monthlyData=Object.entries(monthly).sort(([a],[b])=>a.localeCompare(b)).slice(-6).map(([m,d])=>({
      mes:m.substring(5)+"/"+m.substring(2,4),
      score:Math.round(d.score/d.total),
      total:d.total,
    }));
    const supData=Object.entries(supMap).map(([name,d])=>({
      name:name.split(" ")[0],
      avg:Math.round(d.scores.reduce((a,b)=>a+b,0)/d.scores.length),
      count:d.count,
    }));

    return{sim,nao,parcial,totalR,avgScore,pieData,monthlyData,supData};
  },[filtered]);

  const selects=[
    {l:"Período",v:fp,set:setFp,opts:[["30","30 dias"],["60","60 dias"],["90","90 dias"],["365","Geral"]]},
    {l:"Tipo",v:ft,set:setFt,opts:[["todos","Todos"],["start","Start"],["on","ON"],["off","OFF"],["imp","Imprevista"]]},
    {l:"Supervisor",v:fs,set:setFs,opts:[["todos","Todos"],...SUPERVISORS.map(s=>[s,s.split(" ")[0]])]},
    {l:"Técnico",v:ftech,set:setFtech,opts:[["todos","Todos"],...TECHNICIANS.map(t=>[t,t.split(" ")[0]])]},
  ];

  return(
    <div className="flex flex-col min-h-screen">
      <div className="sticky top-0 z-30 bg-[#080f1e]/96 backdrop-blur border-b border-white/8 px-4 py-3 flex items-center gap-3">
        <button onClick={()=>setS("home")} className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center text-white/70">←</button>
        <div className="flex-1 font-bold text-white text-sm">Dashboard Operacional</div>
      </div>
      <div className="px-4 pt-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {selects.map(({l,v,set,opts})=>(
            <div key={l} className="flex-shrink-0 flex items-center gap-1.5 bg-white/6 border border-white/10 rounded-xl px-3 py-2">
              <span className="text-white/30 text-xs">{l}:</span>
              <select value={v} onChange={e=>set(e.target.value)} className="bg-transparent text-white text-xs outline-none cursor-pointer">
                {opts.map(([ov,ol])=><option key={ov} value={ov}>{ol}</option>)}
              </select>
            </div>
          ))}
        </div>
      </div>

      {stats?(
        <div className="px-4 pb-8 pt-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {[
              {l:"Total Vistorias",v:filtered.length,icon:"📋",c:"#3b82f6"},
              {l:"Conformidade",v:`${stats.avgScore}%`,icon:"🎯",c:stats.avgScore>=80?"#10b981":stats.avgScore>=55?"#f59e0b":"#ef4444"},
              {l:"Respostas SIM",v:stats.sim,icon:"✅",c:"#10b981"},
              {l:"Respostas NÃO",v:stats.nao,icon:"❌",c:"#ef4444"},
              {l:"Parciais",v:stats.parcial,icon:"◐",c:"#f59e0b"},
              {l:"Itens Avaliados",v:stats.totalR,icon:"📊",c:"#8b5cf6"},
            ].map(({l,v,icon,c})=>(
              <div key={l} style={{borderColor:c+"30",background:c+"0c"}} className="border rounded-2xl p-4">
                <div className="text-xl mb-1">{icon}</div>
                <div style={{color:c}} className="text-2xl font-black leading-none">{v}</div>
                <div className="text-white/35 text-xs mt-1">{l}</div>
              </div>
            ))}
          </div>

          <Card>
            <SectionTitle icon="🍕">Distribuição por Tipo</SectionTitle>
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={stats.pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={68} paddingAngle={4}>
                  {stats.pieData.map((e,i)=><Cell key={i} fill={e.color}/>)}
                </Pie>
                <Tooltip contentStyle={{background:"#111827",border:"1px solid #1f2937",borderRadius:8,fontSize:12}}/>
                <Legend wrapperStyle={{fontSize:11}}/>
              </PieChart>
            </ResponsiveContainer>
          </Card>

          <Card>
            <SectionTitle icon="📈">Evolução Mensal – Score</SectionTitle>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={stats.monthlyData} margin={{top:5,right:10,left:-20,bottom:0}}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff09"/>
                <XAxis dataKey="mes" tick={{fill:"#ffffff35",fontSize:11}}/>
                <YAxis tick={{fill:"#ffffff35",fontSize:11}} domain={[0,100]}/>
                <Tooltip contentStyle={{background:"#111827",border:"1px solid #1f2937",borderRadius:8,fontSize:12}}/>
                <Line type="monotone" dataKey="score" stroke="#3b82f6" strokeWidth={2.5} dot={{fill:"#3b82f6",r:4}} name="Score %"/>
              </LineChart>
            </ResponsiveContainer>
          </Card>

          <Card>
            <SectionTitle icon="📊">Vistorias por Mês</SectionTitle>
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={stats.monthlyData} margin={{top:5,right:10,left:-20,bottom:0}}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff09"/>
                <XAxis dataKey="mes" tick={{fill:"#ffffff35",fontSize:11}}/>
                <YAxis tick={{fill:"#ffffff35",fontSize:11}}/>
                <Tooltip contentStyle={{background:"#111827",border:"1px solid #1f2937",borderRadius:8,fontSize:12}}/>
                <Bar dataKey="total" fill="#8b5cf6" radius={[6,6,0,0]} name="Qtd"/>
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card>
            <SectionTitle icon="👤">Score Médio por Supervisor</SectionTitle>
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={stats.supData} margin={{top:5,right:10,left:-20,bottom:0}}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff09"/>
                <XAxis dataKey="name" tick={{fill:"#ffffff35",fontSize:11}}/>
                <YAxis tick={{fill:"#ffffff35",fontSize:11}} domain={[0,100]}/>
                <Tooltip contentStyle={{background:"#111827",border:"1px solid #1f2937",borderRadius:8,fontSize:12}}/>
                <Bar dataKey="avg" fill="#10b981" radius={[6,6,0,0]} name="Score %"/>
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>
      ):(
        <div className="flex-1 flex items-center justify-center text-white/25 text-sm py-20">Sem dados no período selecionado.</div>
      )}
    </div>
  );
}

// ── RANKING ───────────────────────────────────────────────────────────────────────
function Ranking({data,setS}){
  const [fp,setFp]=useState("90");
  const [view,setView]=useState("best");

  const filtered=useMemo(()=>{
    const cut=new Date();cut.setDate(cut.getDate()-parseInt(fp));
    return data.filter(v=>new Date(v.date)>=cut);
  },[data,fp]);

  const techStats=useMemo(()=>{
    const map={};
    filtered.forEach(v=>{
      if(!map[v.technician])map[v.technician]={scores:[],sim:0,nao:0,parcial:0,count:0};
      map[v.technician].scores.push(v.score);map[v.technician].count++;
      (QUESTIONS[v.tipo]||[]).forEach(q=>{
        const r=v.respostas[q.id];
        if(r==="sim")map[v.technician].sim++;
        else if(r==="parcial")map[v.technician].parcial++;
        else map[v.technician].nao++;
      });
    });
    return Object.entries(map).map(([name,d])=>({
      name,avg:Math.round(d.scores.reduce((a,b)=>a+b,0)/d.scores.length),
      count:d.count,sim:d.sim,nao:d.nao,parcial:d.parcial,
    })).sort((a,b)=>view==="best"?b.avg-a.avg:a.avg-b.avg);
  },[filtered,view]);

  const medals=["🥇","🥈","🥉"];

  return(
    <div className="flex flex-col min-h-screen">
      <div className="sticky top-0 z-30 bg-[#080f1e]/96 backdrop-blur border-b border-white/8 px-4 py-3 flex items-center gap-3">
        <button onClick={()=>setS("home")} className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center text-white/70">←</button>
        <div className="flex-1 font-bold text-white text-sm">Ranking de Técnicos</div>
        <select value={fp} onChange={e=>setFp(e.target.value)} className="bg-white/8 border border-white/15 text-white text-xs rounded-xl px-2 py-1.5 outline-none">
          {[["30","30d"],["60","60d"],["90","90d"],["365","Geral"]].map(([v,l])=><option key={v} value={v}>{l}</option>)}
        </select>
      </div>
      <div className="px-4 pt-4 pb-2">
        <div className="flex bg-white/6 border border-white/10 rounded-2xl p-1 gap-1">
          {[["best","🏆 Melhor Desempenho"],["worst","⚠️ Mais Atenção"]].map(([v,l])=>(
            <button key={v} onClick={()=>setView(v)}
              className={cn("flex-1 py-2.5 rounded-xl text-xs font-bold transition-all",
                view===v?"bg-blue-600 text-white shadow-lg":"text-white/40 hover:text-white"
              )}>{l}</button>
          ))}
        </div>
      </div>
      <div className="flex-1 px-4 py-2 space-y-2">
        {techStats.map((t,i)=>(
          <div key={t.name} className={cn("flex items-center gap-3 rounded-2xl p-4 border transition-all",
            i===0?"bg-amber-500/8 border-amber-500/22":"bg-white/4 border-white/8"
          )}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{background:i<3?"#f59e0b1a":"#ffffff0a"}}>
              {i<3?<span className="text-xl">{medals[i]}</span>:<span className="text-white/25 font-black text-sm">#{i+1}</span>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-white font-bold text-sm truncate">{t.name}</div>
              <div className="flex items-center gap-2 mt-1.5">
                <div className="flex-1 h-1.5 bg-white/8 rounded-full overflow-hidden">
                  <div style={{width:`${t.avg}%`,background:t.avg>=80?"#10b981":t.avg>=55?"#f59e0b":"#ef4444"}} className="h-full rounded-full"/>
                </div>
                <span className="text-white/25 text-xs flex-shrink-0">{t.count}x</span>
              </div>
              <div className="flex gap-3 mt-1">
                <span className="text-emerald-400/65 text-xs">✓ {t.sim}</span>
                <span className="text-amber-400/65 text-xs">◐ {t.parcial}</span>
                <span className="text-red-400/65 text-xs">✗ {t.nao}</span>
              </div>
            </div>
            <div className={cn("text-xl font-black flex-shrink-0",t.avg>=80?"text-emerald-400":t.avg>=55?"text-amber-400":"text-red-400")}>{t.avg}%</div>
          </div>
        ))}
        {!techStats.length&&<div className="text-center py-12 text-white/25 text-sm">Sem dados no período.</div>}
      </div>
    </div>
  );
}

// ── PONTOS DE ATENÇÃO ─────────────────────────────────────────────────────────────
function Atencao({data,setS}){
  const [fp,setFp]=useState("60");

  const filtered=useMemo(()=>{
    const cut=new Date();cut.setDate(cut.getDate()-parseInt(fp));
    return data.filter(v=>new Date(v.date)>=cut);
  },[data,fp]);

  const{failures,criticals,catRates}=useMemo(()=>{
    const qFail={};
    const techMap={};
    const catNao={start:0,off:0,on:0,imp:0};
    const catTotal={start:0,off:0,on:0,imp:0};

    filtered.forEach(v=>{
      if(!techMap[v.technician])techMap[v.technician]={nao:0,total:0,scores:[]};
      techMap[v.technician].scores.push(v.score);
      (QUESTIONS[v.tipo]||[]).forEach(q=>{
        const r=v.respostas[q.id];
        techMap[v.technician].total++;
        catTotal[v.tipo]++;
        if(r==="nao"){
          techMap[v.technician].nao++;
          catNao[v.tipo]++;
          if(!qFail[q.id])qFail[q.id]={text:q.text,count:0,tipo:v.tipo};
          qFail[q.id].count++;
        }
      });
    });

    const failures=Object.values(qFail).sort((a,b)=>b.count-a.count).slice(0,8);
    const criticals=Object.entries(techMap)
      .map(([name,d])=>({name,nao:d.nao,avg:Math.round(d.scores.reduce((a,b)=>a+b,0)/d.scores.length)}))
      .filter(t=>t.avg<65).sort((a,b)=>a.avg-b.avg);
    const catRates=Object.entries(catNao).map(([tipo,n])=>({
      label:{start:"Start",on:"ON",off:"OFF",imp:"Imprevista"}[tipo],
      icon:TIPO_ICONS[tipo],color:TIPO_COLORS[tipo],
      rate:catTotal[tipo]?Math.round((n/catTotal[tipo])*100):0,
    })).sort((a,b)=>b.rate-a.rate);

    return{failures,criticals,catRates};
  },[filtered]);

  return(
    <div className="flex flex-col min-h-screen">
      <div className="sticky top-0 z-30 bg-[#080f1e]/96 backdrop-blur border-b border-white/8 px-4 py-3 flex items-center gap-3">
        <button onClick={()=>setS("home")} className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center text-white/70">←</button>
        <div className="flex-1 font-bold text-white text-sm">Pontos de Atenção</div>
        <select value={fp} onChange={e=>setFp(e.target.value)} className="bg-white/8 border border-white/15 text-white text-xs rounded-xl px-2 py-1.5 outline-none">
          {[["30","30d"],["60","60d"],["90","90d"]].map(([v,l])=><option key={v} value={v}>{l}</option>)}
        </select>
      </div>
      <div className="flex-1 px-4 py-5 space-y-4">
        {criticals.length>0&&(
          <Card>
            <SectionTitle icon="🚨">Técnicos em Alerta Crítico</SectionTitle>
            <div className="space-y-2">
              {criticals.map(t=>(
                <div key={t.name} className="flex items-center gap-3 bg-red-500/8 border border-red-500/20 rounded-xl px-4 py-3">
                  <span className="text-red-400 text-xl">⚠️</span>
                  <div className="flex-1">
                    <div className="text-red-300 font-bold text-sm">{t.name}</div>
                    <div className="text-red-400/55 text-xs">{t.nao} reprovações · score médio {t.avg}%</div>
                  </div>
                  <ScoreBadge score={t.avg} size="sm"/>
                </div>
              ))}
            </div>
          </Card>
        )}

        {!criticals.length&&(
          <div className="bg-emerald-500/8 border border-emerald-500/20 rounded-2xl p-5 text-center">
            <div className="text-3xl mb-2">✅</div>
            <div className="text-emerald-400 font-bold text-sm">Nenhum técnico em alerta crítico!</div>
            <div className="text-emerald-400/50 text-xs mt-1">Todos com score acima de 65%</div>
          </div>
        )}

        <Card>
          <SectionTitle icon="📊">Taxa de Reprovação por Tipo</SectionTitle>
          {catRates.map(c=>(
            <div key={c.label} className="flex items-center gap-3 mb-3.5 last:mb-0">
              <span className="text-lg">{c.icon}</span>
              <div className="flex-1">
                <div className="flex justify-between mb-1.5">
                  <span style={{color:c.color}} className="text-xs font-bold">{c.label}</span>
                  <span className="text-white/35 text-xs">{c.rate}% NÃO</span>
                </div>
                <div className="h-2 bg-white/8 rounded-full overflow-hidden">
                  <div style={{width:`${c.rate}%`,background:c.color}} className="h-full rounded-full transition-all"/>
                </div>
              </div>
            </div>
          ))}
        </Card>

        <Card>
          <SectionTitle icon="❌">Top Questões com Mais Reprovações</SectionTitle>
          {failures.length>0?(
            <div className="space-y-2">
              {failures.map((f,i)=>(
                <div key={i} className="flex items-start gap-3 bg-white/4 rounded-xl p-3.5">
                  <div className="w-6 h-6 rounded-lg bg-red-500/18 text-red-400 text-xs flex items-center justify-center font-black flex-shrink-0 mt-0.5">{i+1}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white/65 text-xs leading-relaxed">{f.text}</p>
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <TipoBadge tipo={f.tipo}/>
                      <span className="text-red-400 text-xs font-bold">{f.count}× reprovado</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ):(
            <div className="text-emerald-400 text-sm text-center py-4">🎉 Nenhuma reprovação no período!</div>
          )}
        </Card>
      </div>
    </div>
  );
}

// ── ROOT ──────────────────────────────────────────────────────────────────────────
export default function App(){
  const [screen,setScreen]=useState("home");
  const [vistorias,setVistorias]=useState(buildMock);
  const addVistoria=useCallback(v=>setVistorias(p=>[v,...p]),[]);
  const avg=useMemo(()=>!vistorias.length?0:Math.round(vistorias.reduce((a,b)=>a+b.score,0)/vistorias.length),[vistorias]);

  return(
    <div style={{fontFamily:"'Barlow','DM Sans',sans-serif",background:"#080f1e",minHeight:"100vh",color:"#e2e8f0",maxWidth:"480px",margin:"0 auto",position:"relative"}}>
      <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>
      <div style={{position:"fixed",inset:0,zIndex:0,pointerEvents:"none",background:"radial-gradient(ellipse at 15% 0%,#1e3a5f2a 0%,transparent 55%),radial-gradient(ellipse at 85% 100%,#1e1a3f1a 0%,transparent 55%)",maxWidth:"480px",margin:"0 auto"}}/>
      <div style={{position:"relative",zIndex:1}}>
        {screen==="home"      &&<Home setS={setScreen} total={vistorias.length} avg={avg}/>}
        {screen==="nova"      &&<NovaVistoria onSave={addVistoria} setS={setScreen}/>}
        {screen==="historico" &&<Historico data={vistorias} setS={setScreen}/>}
        {screen==="dashboard" &&<Dashboard data={vistorias} setS={setScreen}/>}
        {screen==="ranking"   &&<Ranking data={vistorias} setS={setScreen}/>}
        {screen==="atencao"   &&<Atencao data={vistorias} setS={setScreen}/>}
      </div>
    </div>
  );
}
